package enforce_test

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/globulario/services/golang/awareness/enforce"
)

func writeGoSrc(t *testing.T, dir, name, content string) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(dir, name), []byte(content), 0o644); err != nil {
		t.Fatalf("write %s: %v", name, err)
	}
}

// Test 1: Well-formed annotations produce no findings.
func TestValidateAnnotationsClean(t *testing.T) {
	dir := t.TempDir()
	writeGoSrc(t, dir, "ok.go", `package pkg

//globular:enforces infra.desired_hash_consistency
//globular:hash_schema infra_desired_hash
//globular:state_transition DESIRED -> INSTALLED
//globular:tested_by TestMyFunction
func MyFunction() {}
`)

	findings := enforce.ValidateAnnotations(dir)
	if len(findings) != 0 {
		t.Errorf("expected no findings, got %d: %v", len(findings), findings)
	}
}

// Test 2: Malformed state_transition (no arrow) produces ERROR.
func TestValidateAnnotationsMalformedStateTransition(t *testing.T) {
	dir := t.TempDir()
	writeGoSrc(t, dir, "bad.go", `package pkg

//globular:state_transition DESIREDINSTALLED
func Foo() {}
`)

	findings := enforce.ValidateAnnotations(dir)
	found := false
	for _, f := range findings {
		if f.Code == "MALFORMED_STATE_TRANSITION" && f.Severity == enforce.SeverityError {
			found = true
		}
	}
	if !found {
		t.Errorf("expected MALFORMED_STATE_TRANSITION ERROR, got: %v", findings)
	}
}

// Test 3: tested_by that doesn't start with Test/Benchmark/Example → ERROR.
func TestValidateAnnotationsBadTestName(t *testing.T) {
	dir := t.TempDir()
	writeGoSrc(t, dir, "bad.go", `package pkg

//globular:tested_by myTestHelper
func Bar() {}
`)

	findings := enforce.ValidateAnnotations(dir)
	found := false
	for _, f := range findings {
		if f.Code == "ANNOTATION_BAD_TEST_NAME" && f.Severity == enforce.SeverityError {
			found = true
		}
	}
	if !found {
		t.Errorf("expected ANNOTATION_BAD_TEST_NAME ERROR, got: %v", findings)
	}
}

// Test 4: Annotation with no value produces ERROR.
func TestValidateAnnotationsMissingValue(t *testing.T) {
	dir := t.TempDir()
	writeGoSrc(t, dir, "bad.go", `package pkg

//globular:enforces
func Baz() {}
`)

	findings := enforce.ValidateAnnotations(dir)
	found := false
	for _, f := range findings {
		if f.Code == "ANNOTATION_MISSING_VALUE" && f.Severity == enforce.SeverityError {
			found = true
		}
	}
	if !found {
		t.Errorf("expected ANNOTATION_MISSING_VALUE ERROR, got: %v", findings)
	}
}
